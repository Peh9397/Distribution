package com.green.distribution.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.green.distribution.dao.OrderProductDao;
import com.green.distribution.model.OrderProduct;

@Service
public class OrderProductServiceImpl implements OrderProductService {

	@Autowired
	private OrderProductDao opd;

	@Override
	public List<OrderProduct> orderList(OrderProduct orderProduct) {
		// TODO Auto-generated method stub
		return opd.orderList(orderProduct);
	}
	
//	@Override
//	public List<OrderProduct> orderList(OrderProduct order) {
//		// TODO Auto-generated method stub
//		return opd.orderList(order);
//	}
}
