package com.green.distribution.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.green.distribution.model.OrderProduct;
import com.green.distribution.service.BuyerService;
import com.green.distribution.service.EmployeeService;
import com.green.distribution.service.OrderProductService;
import com.green.distribution.service.ProductService;

import net.sf.json.JSONArray;

@Controller
public class OrderProductController {
	@Autowired
	private OrderProductService ops;
	
	@Autowired
	private ProductService ps;
	
	@Autowired
	private EmployeeService es;
	
	@Autowired
	private BuyerService bs;
	
	@RequestMapping("orderList")
	public String order(OrderProduct orderProduct, Model model ) {
		
		List<OrderProduct> list = ops.orderList(orderProduct);
		
		
		return "nolay/orderList";
	}
	
//	@RequestMapping("orderInsert")
//	@ResponseBody
//	public Map<String, Object> orderInsert(HttpSession sesion, OrderProduct orderProduct, Model model) {
//		Map<String, Object> resutl = new HashMap<String, Object>();
//		
//		try {
//			List<Map<String, Object>> info = new ArryList<Map<String, Object>>();
//			info = JSONArray.fromobject(data);
//			
//			for (Map<String, Object> orderInfo : info) {
//				String eName = (String) orderInfo.get("ENAME");
//				String buyerCd = (String) orderInfo.get("buyerCd");
//				String buyerCd = (String) orderInfo.get("buyerCd");
//				String buyerCd = (String) orderInfo.get("buyerCd");
//				String buyerCd = (String) orderInfo.get("buyerCd");
//				String buyerCd = (String) orderInfo.get("buyerCd");
//				
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return null;
//		
//	}
	
	@RequestMapping("orderInsertForm")
	public String orderInsertForm(HttpSession session, OrderProduct order, Model model ) {
		
		
//		List<OrderProduct> orderList = ops.orderList(order);
//		
		return "nolay/orderInsertForm";
	}
	
}
