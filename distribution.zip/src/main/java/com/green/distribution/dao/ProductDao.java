package com.green.distribution.dao;

public interface ProductDao {

}
