package com.green.distribution.dao;

import java.util.List;

import com.green.distribution.model.Employee;

public interface EmployeeDao {

	List<Employee> list();

	void insert(Employee employee);
	
	List<Employee> search(Employee employee);

	void update(Employee employee);

	Employee select(String EMPCD);

	int getTotal(Employee employee);

	void employeeDelete(String EMPCD);

	void employeeRestore(String EMPCD);

	int getSALCount(String DEPT);

	Employee listForExcel(Employee item);

	
}