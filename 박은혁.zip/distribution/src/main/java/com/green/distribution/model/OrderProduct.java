package com.green.distribution.model;

public class OrderProduct {

}
