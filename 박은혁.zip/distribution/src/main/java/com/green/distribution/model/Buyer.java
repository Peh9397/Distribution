package com.green.distribution.model;

import java.sql.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class Buyer {
	private String BUYERCD; 		// 구매자 코드
	private String BNAME; 			// 회사명
	private String COMPANYNO;		// 사업자 번호
	private String CEO;				// 대표자
	private String MANAGER;			// 담당자
	private String ADDRESS;			// 주소
	private String TEL;				// 연락처
	private String EMAIL;			// 이메일
	private Date ADDDATE;			// 등록일
	private String DEL;				// 삭제
	private String REMARK;			// 비고
	private Date STATEDATEDATE;		// 최종변경일
}