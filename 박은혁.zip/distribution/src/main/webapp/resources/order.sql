--고객코드--
select * from M_BUYER;


insert into BUYER values ('CVS001', 'KR', 'BGF리테일', '황시유', '서울특별시 강남구 테헤란로 405', '02-1234-1234', 'hwang@cu.com',sysdate, 'N', null);
insert into BUYER values ('CVS002', 'KR', 'GS리테일', '이시보', '서울시 강남구 논현로 508', '02-5678-1234', 'lee25@gs.com',sysdate, 'N', null);
insert into BUYER values ('CVS003', 'KR', '롯데', '김로티', '서울특별시 송파구 올림픽로 300', '02-4321-4321', 'lotti@seven.com',sysdate, 'N', null);
insert into BUYER values ('CVS004', 'KR', '이마트24', '이나나', '서울특별시 성동구 광나루로 310', '02-5432-1234', 'nanana@emart.com',sysdate, 'N', null);
insert into BUYER values ('CVS005', 'KR', '미니스톱', '박미니', '서울특별시 서초구 효령로 11', '02-1321-1432', 'mini@stop.com',sysdate, 'N', null);
insert into BUYER values ('MAT001', 'KR', '롯데마트', '이해피', '서울특별시 성동구 뚝섬로 377', '02-6431-2142', 'mini@stop.com',sysdate, 'N', null);
insert into BUYER values ('MAT002', 'KR', '이마트', '이해민','서울특별시 강남구 테헤란로 123', '02-1234-5678', 'haemin@naver.com',sysdate,'N', null);
insert into BUYER values ('FOD001', 'KR', 'CJ제일제당', '최선희','서울특별시 강남구 테헤란로 123', '02-1234-5678', 'sunny@naver.com',sysdate,'N', null);
insert into BUYER values ('FOD002', 'KR', '롯데푸드', '김창률',	'서울특별시 강남구 테헤란로 123', '02-1234-5678', 'chang@naver.com',sysdate,'N', null);
insert into BUYER values ('FOD003', 'KR', '오뚜기', '박수인',	'서울특별시 강남구 테헤란로 32', '02-1234-5678', 'sooin818@naver.com',sysdate,'N', null);
insert into BUYER values ('FOD004', 'KR', '농심', '박현서',	'서울특별시 강남구 테헤란로 14', '02-1234-5678', 'phs@naver.com',sysdate,'N', null);
insert into BUYER values ('FOD005', 'CN', '롯데푸드', 'Wang fei', '서울특별시 강남구 테헤란로 123', '02-1234-5678', 'wangfei@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD006', 'CN', '칭따오', 'Zhao wei','서울특별시 강남구 테헤란로 12', '02-1234-5678', 'zhaowei@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD007', 'US', '크래프트푸드', 'Ashley Park','서울특별시 강남구 테헤란로 4', '02-1234-5678', 'ashleypark@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD008', 'US', '켈로그', 'John Brown','서울특별시 강남구 테헤란로 5', '02-1234-5678', 'johnbrown@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD009', 'VN', '비나밀크', 'Nguyen Xuan Phuc','서울특별시 강남구 테헤란로88', '02-1234-5678', 'nguyenxuanphuc@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD010', 'JP', '아지노모토', 'Toriyama Akira','서울특별시 강남구 테헤란로 33', '02-1234-5678', 'toriyamaakira@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD011', 'IN', '네슬레인디아', 'Kabir Bedi','서울특별시 강남구 테헤란로 44', '02-1234-5678', 'kabirbedi@google.com',sysdate,'N', null);
insert into BUYER values ('FOD012', 'DE', '하리보', 'Michael Hofmann','서울특별시 강남구 테헤란로 12', '02-1234-5678', 'michaelhofmann@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD013', 'CH', '네슬레', 'Granit Xhaka','서울특별시 강남구 테헤란로 12', '02-1234-5678', 'granitxhaka@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD014', 'GB', '영국연합식품', 'James Brown', '서울특별시 강남구 테헤란로 13', '02-1234-5678', 'jamesbrown@google.com',sysdate, 'N', null);
insert into BUYER values ('FOD015', 'SG', '월마인터네셔널', 'Baihakki Khaizan', '서울특별시 강남구 테헤란로 133', '02-1234-5678', 'baihakkikhaizan@google.com',sysdate, 'N', null);

--직원
select * from EMPLOYEE

insert into EMPLOYEE values ('SAL001', '김영동', '1234', '영업', '사원', '010-1111-1111', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('SAL002', '김찬양', '1234', '영업', '대리', '010-2222-2222', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('SAL003', '박은혁', '1234', '영업', '과장', '010-3333-3333', 'Y', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('SAL004', '최승일', '1234', '영업', '차장', '010-5555-5555', 'Y', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('SAL005', '김찬혁', '1234', '영업', '부장', '010-6666-6666', 'Y', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('MNG001', '영동김', '1234', '관리', '사원', '010-7777-7777', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('MNG002', '찬양김', '1234', '관리', '대리', '010-8888-8888', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('MNG003', '은혁박', '1234', '관리', '과장', '010-9999-9999', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('MNG004', '승일최', '1234', '관리', '차장', '010-1010-1010', 'N', sysdate, 'N', '미정', null );
insert into EMPLOYEE values ('MNG005', '최혁찬', '1234', '관리', '부장', '010-0101-0101', 'Y', sysdate, 'N', '미정', null );