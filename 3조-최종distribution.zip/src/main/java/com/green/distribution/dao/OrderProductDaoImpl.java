package com.green.distribution.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.green.distribution.model.OrderProduct;

@Repository
public class OrderProductDaoImpl implements OrderProductDao {
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<OrderProduct> orderList(OrderProduct orderProduct) {
		// TODO Auto-generated method stub
		return sst.selectList("orderns.orderList", orderProduct);
	}

	
	
//	@Override
//	public List<OrderProduct> orderList(OrderProduct order) {
//		// TODO Auto-generated method stub
//		return sst.selectList("orderns.orderList", order);
//	}
}
